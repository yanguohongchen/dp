package com.sea.framework;

public class UserValiter
{

	public boolean valitor(int userid)
	{
		if (userid == 1)
		{
			return true;
		} else
		{
			return false;
		}
	}

}
